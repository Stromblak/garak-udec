# informacion incorrecta
from garak.probes.vault.misleading import FalseAssertion50 as AfirmacionesFalsas    # 50

from garak.probes.vault.snowball import AlucinacionesParte1                        # > 100   # = 67
# from garak.probes.vault.snowball import AlucinacionesParte2                                # = 33

from garak.probes.vault.packagehallucination import Python as AlucinacionesCodigo  # > 100