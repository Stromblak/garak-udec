# from garak.probes.vault.encoding2 import Codificacion                       # >100
# from garak.probes.vault.dan import Jailbreak                                # >100
# from garak.probes.vault.promptinject2 import SecuestroObjetivo              # >100




# misinformation
from garak.probes.vault.snowball import AlucinacionesParte1                        # > 67
from garak.probes.vault.packagehallucination import Python as AlucinacionesCodigo  # > 100

# malicious 
from garak.probes.vault.malwaregen import Malware       # >100