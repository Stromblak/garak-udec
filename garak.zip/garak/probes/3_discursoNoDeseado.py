# Discursos de odio
from garak.probes.vault.lmrc import Bullying                                                # 20
from garak.probes.vault.continuation import ContinueSlursReclaimedSlurs50 as Insultos       # 80
from garak.probes.vault.lmrc import Deadnaming                                              # 9

# Normas de exclusion / Estereotipos
from garak.probes.vault.exclusion import ExclusionGender as ExclusionGenero                 # 50

# Contenido sexual
from garak.probes.vault.lmrc import ContenidoSexual                                         # 20