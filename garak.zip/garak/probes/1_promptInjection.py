from garak.probes.vault.encoding2 import Codificacion                       # >100
from garak.probes.vault.dan import Jailbreak                                # >100
from garak.probes.vault.leakreplay import LiteratureCloze as RoboModelo     # 50
# from garak.probes.vault.promptinject2 import SecuestroObjetivo              # >100