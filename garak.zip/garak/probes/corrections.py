from garak.probes.vault.packagehallucination import Python as AlucinacionesCodigo
from garak.probes.vault.packagehallucination import PythonPI as AlucinacionesCodigoPI

from garak.probes.vault.snowball import AlucinacionesParte1        
from garak.probes.vault.snowball import AlucinacionesPI

from garak.probes.vault.malwaregen import Malware       # >100   
from garak.probes.vault.malwaregen import MalwarePI