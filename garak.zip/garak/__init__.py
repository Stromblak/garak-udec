"""Top-level package for garak"""

__version__ = "0.9.0.7"
__app__ = "garak"
__description__ = "LLM security probe"
